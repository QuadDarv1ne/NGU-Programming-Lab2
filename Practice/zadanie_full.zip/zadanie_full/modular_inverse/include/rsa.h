#ifndef RSA_H
#define RSA_H

// Демонстрация работы RSA
void run_rsa_demo();

#endif