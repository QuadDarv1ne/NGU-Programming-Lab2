#ifndef MODULAR_INVERSE_H
#define MODULAR_INVERSE_H

// Базовый метод вычисления обратного элемента
int modularInverse(int v, int c);

#endif