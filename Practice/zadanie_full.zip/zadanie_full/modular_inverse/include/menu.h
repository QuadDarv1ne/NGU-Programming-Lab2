#ifndef MENU_H
#define MENU_H

// Основное меню программы
void run_main_menu();

#endif