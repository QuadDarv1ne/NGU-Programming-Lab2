#include "menu.h"

int main() {
    run_main_menu();
    return 0;
}